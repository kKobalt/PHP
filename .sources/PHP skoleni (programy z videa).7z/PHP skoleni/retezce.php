<!DOCTYPE html>
<html>
<head>
   <meta charset="UTF-8">
</head>
<body>

<?php
echo "Dolar je \$. Konec řádku, který se v prohlížeči neprojeví je\n. Zpětné lomítko je \\. Tabelátor, který se v prohlížeči neprojeví je \t.";
?>

</body>
</html>

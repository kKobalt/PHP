<!DOCTYPE html>
<html>
<head>
   <meta charset="UTF-8">
</head>
<body>

<?php
for ($a = 1; $a < 10; $a++)
{
  echo "$a<br>";
}
?>

</body>
</html>

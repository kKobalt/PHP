<!DOCTYPE html>
<html>
<head>
   <meta charset="UTF-8">
</head>
<body>

<?php
$a = 1;
echo "$a<br>";
$a = "Ahoj";
echo "$a<br>";
$a = 5.3;
echo "$a<br>";
?>

<?php
$jmeno ="Radim";
$prijmeni = " Dostal";
$cele = $jmeno . $prijmeni;
echo $cele;
?>
</body>
</html>

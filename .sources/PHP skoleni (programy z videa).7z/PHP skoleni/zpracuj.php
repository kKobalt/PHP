<!DOCTYPE html>
<html>
<head>
   <meta charset="UTF-8">
</head>
<body>
<?php
$prvek = htmlspecialchars($_POST["prvek"]);
echo $prvek;
?>
</body>
</head>

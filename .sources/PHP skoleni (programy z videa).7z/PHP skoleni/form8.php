<!DOCTYPE html>
<html>
<head>
   <meta charset="UTF-8">
</head>
<body>
<form method="POST" action="jmeno.php">
<table>
<tr>
  <th>Jméno v pátém pádu:</th>
  <td><input type="text" name="jmeno"></td>
</tr>
<tr>
<th colspan="2"><input type="submit" value="odešli" ></th>
</form>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
   <meta charset="UTF-8">
</head>
<body>
<p>Právě je <strong><?php
echo date("d.m.Y G:i:s");
?></strong>.</p>
</body>
</head>

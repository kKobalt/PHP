<!DOCTYPE html>
<html>
<head>
   <meta charset="UTF-8">
</head>
<body>
<form method="POST" action="zpracuj.php">
<input name="prvek" type="text" value="Sem něco patří" ><br>
<input type="submit" value="odešli" >
</form>
</body>
</html>

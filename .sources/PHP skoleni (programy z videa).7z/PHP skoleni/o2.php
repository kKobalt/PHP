<!DOCTYPE html>
<html>
<head>
   <meta charset="UTF-8">
</head>
<body>
<?php
echo $_SERVER['HTTP_REFERER']; 
?>
</body>
</html>

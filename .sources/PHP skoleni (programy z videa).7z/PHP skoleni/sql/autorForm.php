<!DOCTYPE html>
<html>
<head>
   <meta charset="UTF-8">
</head>
<body>
<form action="vyberAutor.php" method="POST">
<table>
<tr>
	<th>Jméno autora:</th>
	<td><input type="text" name="jmeno" ></td>
</tr>
</table>
<input type="submit" value="Zobrazit" >
</form>
</body>
</html>
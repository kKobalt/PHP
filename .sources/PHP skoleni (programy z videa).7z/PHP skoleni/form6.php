<!DOCTYPE html>
<html>
<head>
   <meta charset="UTF-8">
</head>
<body>
<form method="POST" action="zpracuj.php">
<textarea cols="20" rows="5" name="prvek">
  Nějaký text
</textarea>
<input type="submit" value="odešli" >
<input type="reset" value="původní hodnoty" >
</form>
</body>
</html>

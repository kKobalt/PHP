<!DOCTYPE html>
<html>
<head>
   <meta charset="UTF-8">
</head>
<body>
<form method="POST" action="zpracuj.php">
<select name="prvek">
		<option value="1">Hodnota jedna</option>
		<option value="2">Hodnota dvě</option>
</select>
<input type="submit" value="Odešli">
</form>
</body>
</html>
<!DOCTYPE html>
<html>
<head>
   <meta charset="UTF-8">
</head>
<body>
<form method="POST" action="login.php">
Jméno:<input name="name" type="text" ><br>
Heslo:<input name="password" type="password" ><br>
<input type="submit" value="Přihlásit se" >
</form>
</body>
</html>

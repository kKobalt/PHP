<!DOCTYPE html>
<html>
<head>
   <meta charset="UTF-8">
</head>
<body>

<?php
$a = 10;
$b = 20;
$c = 30;

if ($a == $b)
{
  echo "a = b";
}
elseif ($a == $c)
{
  echo "a = c";
}
else
{
  echo "a není rovno ani b ani c";
}

?>

</body>
</html>

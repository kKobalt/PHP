﻿<!DOCTYPE html>
<html>
<head>
   <meta charset="UTF-8">
</head>
<body>

<?php
$pole["Jmeno"] = "Radim";
$pole["Jmeno"] = "Změna";
$pole["Prijmeni"] = "Dostál";
$i = "Prijmeni";
echo $pole["Jmeno"];
echo " ";
echo $pole[$i];
//echo $pole["nic"];
?>

</body>
</html>

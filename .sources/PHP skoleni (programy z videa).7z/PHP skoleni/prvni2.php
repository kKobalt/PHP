<!DOCTYPE html>
<html>
<head>
   <meta charset="UTF-8">
</head>
<body>
<p>
<?php
   echo "Ahoj světe";
?>
</p>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
   <meta charset="UTF-8">
</head>
<body>
<form method="POST" action="zpracuj.php">
<input type="hidden" value="hodnota" name="prvek">
<input type="submit" value="odešli" >
</form>
</body>
</html>

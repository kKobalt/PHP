<!DOCTYPE html>
<html>
<head>
   <meta charset="UTF-8">
</head>
<body>Vítej <?php
echo htmlspecialchars($_POST["jmeno"]);
?>
</body>
</html>

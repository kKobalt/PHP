<!DOCTYPE html>
<html>
<head>
   <meta charset="UTF-8">
</head>
<body>

<?php
$a[0] = 1;
$a[1] = 20;
$a[2] = 100;
$a[50] = 50;
echo "$a[0] $a[1] $a[2] $a[50] "; 
?>

</body>
</html>

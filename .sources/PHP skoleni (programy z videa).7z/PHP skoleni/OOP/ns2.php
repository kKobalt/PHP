<?php
   namespace ciziprostorjmen;
   
   class Trida{
    public function metoda(){
      echo "metoda z cizi\Trida";
    }
   }
?>
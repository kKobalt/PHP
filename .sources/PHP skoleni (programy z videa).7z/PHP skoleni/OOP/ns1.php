<?php
   namespace radimuvprostorjmen;
   
   class Trida{
    public function metoda(){
      echo "metoda z radimuvprostorjmen\Trida";
    }
   }
      
?>
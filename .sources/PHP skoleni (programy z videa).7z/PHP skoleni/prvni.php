<?php
   echo "<html>
<head>
</head>
<body><p>Ahoj svete</p></body></html>";
?>

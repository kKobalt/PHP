<!DOCTYPE html>
<html>
<head>
   <meta charset="UTF-8">
</head>
<body>
<a href="o2.php">klik</a>
</body>
</html>

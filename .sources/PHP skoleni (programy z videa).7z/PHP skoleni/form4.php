<!DOCTYPE html>
<html>
<head>
   <meta charset="UTF-8">
</head>
<body>
<form method="POST" action="zpracuj.php">
<input name="prvek" type="radio" value="jednicka" checked > volba 1<br>
<input name="prvek" type="radio" value="dvojka" > volba 2<br>
<input name="prvek" type="radio" value="trojka" > volba 3<br>
<input name="prvek" type="radio" value="ctyrka" > volba 4<br>

<input type="submit" value="odešli" >
</form>
</body>
</html>

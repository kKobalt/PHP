<!DOCTYPE html>
<html>
<head>
   <meta charset="UTF-8">
</head>
<body>
<form method="POST" action="f2.php">
Křestní jméno: <input type="text"  name="krestni"><br>
<input type="submit" value="odešli" >
</form>
</body>
</html>

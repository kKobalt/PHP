<!DOCTYPE html>
<html>
<head>
   <meta charset="UTF-8">
</head>
<body>

<?php
$a = 10;
do
{
  echo "$a<br>";
} while (--$a > 0);
?>

</body>
</html>

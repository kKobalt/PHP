<!DOCTYPE html>
<html>
<head>
   <meta charset="UTF-8">
</head>
<body>
<form method="POST" action="vypocet.php">
<input name="a" type="text" >
<input name="b" type="text" ><br>
<input type="submit" name="soucet" value="+" > <input type="submit" name="rozdil" value="-" >
</form>
</body>
</html>
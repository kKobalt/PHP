<!DOCTYPE html>
<html>
<head>
   <meta charset="UTF-8">
</head>
<body>

<?php
$a = 10;
while (--$a > 0)
{
  echo "$a<br>";
}
?>

</body>
</html>

<!DOCTYPE html>
<html>
<head>
   <meta charset="UTF-8">
</head>
<body>
<?php
echo $_POST["krestni"] . " " . $_POST["prijmeni"];
?>
</body>
</head>
